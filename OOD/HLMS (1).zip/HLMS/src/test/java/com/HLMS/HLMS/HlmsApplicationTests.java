package com.HLMS.HLMS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HlmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
