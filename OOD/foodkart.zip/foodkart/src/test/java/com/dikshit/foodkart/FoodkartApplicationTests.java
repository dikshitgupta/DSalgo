package com.dikshit.foodkart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodkartApplicationTests {

	@Test
	void contextLoads() {
	}

}
