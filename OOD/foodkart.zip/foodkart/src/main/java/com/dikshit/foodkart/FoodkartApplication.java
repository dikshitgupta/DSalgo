package com.dikshit.foodkart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodkartApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodkartApplication.class, args);
	}

}
